from setuptools import setup

setup(name='raj_algebra',
        version='0.1',
        description='Basic algebra',
        packages=['raj_algebra'],
        zip_safe=False)