mkdir basic_algebra

To create environment 
python -m venv basic_algebra

activating environment
source basic_algebra/bin/activate


```
Python 3.7.4 (default, Aug 13 2019, 15:17:50)
[Clang 4.0.1 (tags/RELEASE_401/final)] :: Anaconda, Inc. on darwin
Type "help", "copyright", "credits" or "license" for more information.
>>> from raj_algebra import Algebra
>>> a = Algebra()
>>> a.addition(1,2)
3
>>> a.subtraction(22,2)
20
>>> a.multiplication(2,3)
6
>>> a.division(6,2)
3.0
>>> exit()
```




python setup.py sdist
pip install twine

# commands to upload to the pypi test repository
twine upload --repository-url https://test.pypi.org/legacy/ dist/*
pip install --index-url https://test.pypi.org/simple/ distributions

# command to upload to the pypi repository
twine upload dist/*
pip install distributions